package com.example.lotte.embeddedsystems;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MainActivity extends AppCompatActivity {

    private final static String BROKERADDRESS = "192.168.0.153:1883" ;
    private final static String TOPIC_SETALARM = "SETALARM";

    private MqttAndroidClient androidClient;

    Button btnSetAlarm;
    EditText txtHour, txtMinute, txtDay, txtMonth, txtYear;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtHour = (EditText) findViewById(R.id.sethour);
        txtMinute = (EditText) findViewById(R.id.setminute);
        txtDay = (EditText) findViewById(R.id.setday);
        txtMonth = (EditText) findViewById(R.id.setmonth);
        txtYear = (EditText) findViewById(R.id.setyear);

        btnSetAlarm = (Button) findViewById(R.id.btnsetAlarm);
        btnSetAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                publishAlarm(v);
            }
        });

        String clientID = MqttClient.generateClientId();

        androidClient = new MqttAndroidClient(this.getApplicationContext(), BROKERADDRESS, clientID);

        try{
            IMqttToken token = androidClient.connect();

            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    //connected
                    Toast.makeText(MainActivity.this, "Connected", Toast.LENGTH_LONG).show();
                    setSubscription();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    //failed to connect
                    Toast.makeText(MainActivity.this, "Failed to connect", Toast.LENGTH_LONG).show();

                }
            });
        }catch (MqttException e){
            e.printStackTrace();
        }

        androidClient.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {

            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                if(topic.equalsIgnoreCase(TOPIC_SETALARM)){
                    txtHour.setText(new String(message.getPayload()));
                    txtMinute.setText(new String(message.getPayload()));
                    txtDay.setText(new String(message.getPayload()));
                    txtMonth.setText(new String(message.getPayload()));
                    txtYear.setText(new String(message.getPayload()));
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });
    }

    public void publishAlarm(View v){
        String hour = txtHour.getText().toString();
        String minute = txtMinute.getText().toString();
        String day = txtDay.getText().toString();
        String month = txtMonth.getText().toString();
        String year = txtYear.getText().toString();

        String alarm = txtHour.getText().toString() + "," + txtMinute.getText().toString() + "," + txtDay.getText().toString() + "," + txtMonth.getText().toString() + "," + txtYear.getText().toString();

        try{
            androidClient.publish(TOPIC_SETALARM, alarm.getBytes(), 0, false);

        }catch (MqttException e){
            e.printStackTrace();
        }
    }

    private void setSubscription(){
        try {
            androidClient.subscribe(TOPIC_SETALARM, 0);
        }catch (MqttException e){
            e.printStackTrace();
        }
    }
}
