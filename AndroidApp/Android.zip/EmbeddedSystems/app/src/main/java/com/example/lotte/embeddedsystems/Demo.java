package com.example.lotte.embeddedsystems;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

/**
 * Created by lotte on 9/01/2017.
 */

public class Demo extends AppCompatActivity {
    private final static String BROKERADDRESS = "tcp://192.168.0.153:1883";
    private final static String TOPIC_TEMP = "sensors/temp";

    private String clientId;
    private MqttAndroidClient client;

    private TextView txtTemp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.demo);

        txtTemp = (TextView) findViewById(R.id.txtTemp);

        clientId = MqttClient.generateClientId();

        client = new MqttAndroidClient(this.getApplicationContext(), BROKERADDRESS, clientId);

        try{
            IMqttToken token = client.connect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    //connected
                    Toast.makeText(Demo.this, "Connected", Toast.LENGTH_LONG).show();
                    setSubscription();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    //failed to connect
                    Toast.makeText(Demo.this, "Connection failed", Toast.LENGTH_LONG).show();
                }
            });
        }catch (MqttException e){
            e.printStackTrace();
        }

        client.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {

            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                if(topic.equalsIgnoreCase(TOPIC_TEMP)){
                    txtTemp.setText(new String(message.getPayload() + " °C"));
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });
    }

    private void setSubscription(){
        try{
            client.subscribe(TOPIC_TEMP, 0);
        }catch (MqttException e){
            e.printStackTrace();
        }
    }
}
